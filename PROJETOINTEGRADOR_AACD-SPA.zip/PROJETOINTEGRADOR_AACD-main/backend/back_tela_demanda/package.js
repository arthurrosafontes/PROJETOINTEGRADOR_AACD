[
{
  "name": "hub-aacd-backend",
  "version": "1.0.0",
  "description": "API do HUB AACD (próteses e demandas)",
  "main": "server.js",
  "scripts": {
    "start": "node server.js"
  },
  "dependencies": {
    "cors": "^2.8.5",
    "dotenv": "^16.4.5",
    "express": "^4.19.2",
    "mysql2": "^3.11.0"
  }
}
]